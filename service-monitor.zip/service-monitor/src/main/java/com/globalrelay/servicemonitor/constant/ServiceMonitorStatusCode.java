package com.globalrelay.servicemonitor.constant;

/**
 * Enumerator for task status codes.
 * 
 * @author Ravikiran Butti
 */
public enum ServiceMonitorStatusCode {

	ACTIVE, INACTIVE;
}
